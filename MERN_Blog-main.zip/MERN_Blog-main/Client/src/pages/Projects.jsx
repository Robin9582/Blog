import React from "react";
import { ProjectGrids } from "../components/ProjectGrids";

export default function Projects() {
  return (
    <div>
      <ProjectGrids />
    </div>
  );
}
